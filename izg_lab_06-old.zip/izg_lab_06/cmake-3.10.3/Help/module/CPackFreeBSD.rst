.. cmake-module:: ../../Modules/CPackFreeBSD.cmake
