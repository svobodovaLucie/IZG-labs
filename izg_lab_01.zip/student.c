/******************************************************************************
 * Laborator 01 - Zaklady pocitacove grafiky - IZG
 * ihulik@fit.vutbr.cz
 *
 * $Id: xsvobo1x
 * 
 * Popis: Hlavicky funkci pro funkce studentu
 *
 * Opravy a modifikace:
 * - ibobak@fit.vutbr.cz, orderedDithering
 */

#include "student.h"
#include "globals.h"

#include <time.h>

const int M[] = {
    0, 204, 51, 255,
    68, 136, 187, 119,
    34, 238, 17, 221,
    170, 102, 153, 85
};

const int M_SIDE = 4;

/******************************************************************************
 ******************************************************************************
 Funkce vraci pixel z pozice x, y. Je nutne hlidat frame_bufferu, pokud 
 je dana souradnice mimo hranice, funkce vraci barvu (0, 0, 0).
 Ukol za 0.25 bodu */
S_RGBA getPixel(int x, int y)
{
	// bounds checking
	if (x >= width || y >= height)
		return COLOR_BLACK;	// (0, 0, 0)

	long int offset = x + y * width;
	return frame_buffer[offset];
}
/******************************************************************************
 ******************************************************************************
 Funkce vlozi pixel na pozici x, y. Je nutne hlidat frame_bufferu, pokud 
 je dana souradnice mimo hranice, funkce neprovadi zadnou zmenu.
 Ukol za 0.25 bodu */
void putPixel(int x, int y, S_RGBA color)
{
	// bounds checking
	if (x >= width || y >= height)
		return;

	// offset
	long int offset = x + y * width;
	frame_buffer[offset] = color;
}
/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na odstiny sedi. Vyuziva funkce GetPixel a PutPixel.
 Ukol za 0.5 bodu */
void grayScale()
{
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			// load pixel
			S_RGBA pixel = getPixel(x, y);

			// change colors
			int intensity = ROUND(0.229 * pixel.red + 0.587 * pixel.green + 0.114 * pixel.blue);
			pixel.red = intensity;
			pixel.green = intensity;
			pixel.blue = intensity;

			// put pixel
			putPixel(x, y, pixel);
		}
	}
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci algoritmu maticoveho rozptyleni.
 Ukol za 1 bod */

void orderedDithering()
{
	// convert image to grayscale
	grayScale();

	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int i = x % M_SIDE;
			int j = y % M_SIDE;
			long int offset = x + y * width;

			if (frame_buffer[offset].red > M[i + j * M_SIDE])
				frame_buffer[offset] = COLOR_WHITE;
			else
				frame_buffer[offset] = COLOR_BLACK;
		}
	}
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci algoritmu distribuce chyby.
 Ukol za 1 bod */
void errorDistribution()
{
	// convert image to grayScale
	grayScale();
	int treshold = 128;

	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			long int offset = x + y * width;
			int error;
			
			// convert pixel to black or white
			if (frame_buffer[offset].red > treshold) {
				error = frame_buffer[offset].red - COLOR_WHITE.red;
				frame_buffer[offset] = COLOR_WHITE;
			} else {
				error = frame_buffer[offset].red;
				frame_buffer[offset] = COLOR_BLACK;
			}

			// error distribution and overflow handling
			int buffer;
			if (x + 1 < width) {
				if ((buffer = frame_buffer[(x + 1) + y * width].red + ROUND((0.375) * error)) > COLOR_WHITE.red)
					buffer = COLOR_WHITE.red;
				else if (buffer < COLOR_BLACK.red)
					buffer = COLOR_BLACK.red;
				frame_buffer[(x + 1) + y * width].red = buffer;
				frame_buffer[(x + 1) + y * width].green = buffer;
				frame_buffer[(x + 1) + y * width].blue = buffer;

			}

			if (y + 1 < height) {
				if ((buffer = frame_buffer[x + (y + 1) * width].red + ROUND((0.375) * error)) > COLOR_WHITE.red)
					buffer = COLOR_WHITE.red;
				else if (buffer < COLOR_BLACK.red)
					buffer = COLOR_BLACK.red;
				frame_buffer[x + (y + 1) * width].red = buffer;
				frame_buffer[x + (y + 1) * width].green = buffer;
				frame_buffer[x + (y + 1) * width].blue = buffer;
			}

			if (x + 1 < width && y + 1 < height) {
				if ((buffer = frame_buffer[x + 1 + (y + 1) * width].red + ROUND((0.25) * error)) > COLOR_WHITE.red)
					buffer = COLOR_WHITE.red;
				else if (buffer < COLOR_BLACK.red)
					buffer = COLOR_BLACK.red;
				frame_buffer[x + 1 + (y + 1) * width].red = buffer;
				frame_buffer[x + 1 + (y + 1) * width].green = buffer;
				frame_buffer[x + 1 + (y + 1) * width].blue = buffer;
			}
		}
	}
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci metody prahovani.
 Demonstracni funkce */
void thresholding(int Threshold)
{
	/* Prevedeme obrazek na grayscale */
	grayScale();

	/* Projdeme vsechny pixely obrazku */
	for (int y = 0; y < height; ++y)
		for (int x = 0; x < width; ++x)
		{
			/* Nacteme soucasnou barvu */
			S_RGBA color = getPixel(x, y);

			/* Porovname hodnotu cervene barevne slozky s prahem.
			   Muzeme vyuzit jakoukoli slozku (R, G, B), protoze
			   obrazek je sedotonovy, takze R=G=B */
			if (color.red > Threshold)
				putPixel(x, y, COLOR_WHITE);
			else
				putPixel(x, y, COLOR_BLACK);
		}
}

/******************************************************************************
 ******************************************************************************
 Funkce prevadi obrazek na cernobily pomoci nahodneho rozptyleni. 
 Vyuziva funkce GetPixel, PutPixel a GrayScale.
 Demonstracni funkce. */
void randomDithering()
{
	/* Prevedeme obrazek na grayscale */
	grayScale();

	/* Inicializace generatoru pseudonahodnych cisel */
	srand((unsigned int)time(NULL));

	/* Projdeme vsechny pixely obrazku */
	for (int y = 0; y < height; ++y)
		for (int x = 0; x < width; ++x)
		{
			/* Nacteme soucasnou barvu */
			S_RGBA color = getPixel(x, y);
			
			/* Porovname hodnotu cervene barevne slozky s nahodnym prahem.
			   Muzeme vyuzit jakoukoli slozku (R, G, B), protoze
			   obrazek je sedotonovy, takze R=G=B */
			if (color.red > rand()%255)
			{
				putPixel(x, y, COLOR_WHITE);
			}
			else
				putPixel(x, y, COLOR_BLACK);
		}
}
/*****************************************************************************/
/*****************************************************************************/