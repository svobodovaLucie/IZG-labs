rm -r  build/
rm io.o main.o rasterizer.o student.o color.o
make
cd ./build
./izg_lab_02
