#include "vector.h"

#ifndef _MAIN_H_
#define _MAIN_H_

void getLinePoints(const S_Vector *end_points, S_Vector *out_points);

#endif
