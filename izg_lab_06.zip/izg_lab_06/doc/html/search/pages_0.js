var searchData=
[
  ['izg_20lab06_2e_1',['Izg lab06.',['../index.html',1,'']]]
];
