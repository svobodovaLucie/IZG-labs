var searchData=
[
  ['izg_20lab06_2e_0',['Izg lab06.',['../index.html',1,'']]]
];
