#pragma once

namespace basicCamera{
  class Camera;
  class FreeLookCamera;
  class OrbitCamera;
  class PerspectiveCamera;
}
